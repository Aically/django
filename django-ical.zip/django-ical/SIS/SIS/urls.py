# SIS/urls.py
from django.contrib import admin
from django.urls import path, include
from leaderboard import views  # Import views from your 'leaderboard' app

urlpatterns = [
    path('admin/', admin.site.urls),
    path('leaderboard/', include('leaderboard.urls')),  # URL for your leaderboard app
    path('', views.home, name='home'),  # Home page (root URL)
]

urlpatterns = [
    path('', views.home, name='home'),  # Root URL for the home page
    path('leaderboard/', include('leaderboard.urls')),  # Include leaderboard app URLs
]
