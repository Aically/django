from django.db import models

class Player(models.Model):
    name = models.CharField(max_length=100)
    score = models.IntegerField()
    rank = models.IntegerField(null=False)  # Ensure this is being set

    # Optionally, you can set a default value for rank
    # rank = models.IntegerField(null=False, default=0)
