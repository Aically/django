from django.urls import path
from . import views

urlpatterns = [
    path('', views.player_list, name='player_list'), 
    path('new/', views.player_create, name='player_create'),
    path('edit/<int:pk>/', views.player_update, name='player_update'),
    path('delete/<int:pk>/', views.player_delete, name='player_delete'),
    path('', views.leaderboard, name='leaderboard'), 
]
